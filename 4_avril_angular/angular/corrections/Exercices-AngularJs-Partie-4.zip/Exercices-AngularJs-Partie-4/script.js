//Exercice 1
//Déclaration du module angular "myApp"
angular.module('myApp', [])
/*
on lui donne un controller "myCtrl" qui contient un tablau auquel on passe
le nom de service "$scope" et la fonction qui prends $scope en paramètre.
*/
        .controller('myCtrl', ['$scope', function ($scope) {
          //on initialise la variable "count" à 0
                $scope.count = 0;
                // on crée une fonction qui incrémente "count"
                $scope.myFunction = function () {
                    $scope.count++;
                };

}]);
