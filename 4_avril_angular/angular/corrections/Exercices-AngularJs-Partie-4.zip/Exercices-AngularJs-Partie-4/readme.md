# Exercices AngularJS - Partie 4 : Les directives

# Exercice 1
Faire une page HTML contenant un bouton + , un bouton - et un paragraphe. Au clic sur le bouton + incrémenter le chiffre présent dans le paragraphe de 1. Au clic sur le bouton - décrémenter le chiffre de 1.

# Exercice 2
Faire une page HTML permettant d'afficher la liste des voitures et leur couleur du fichier voiture.json.

# Exercice 3
Faire une page HTML permettant d'afficher la liste des voitures et leur couleur du fichier voiture.json uniquement si la couleur est verte.

# Exercice 4
Faire une page HTML permettant d'afficher la liste des voitures et leur couleur du fichier voiture.json uniquement si la couleur n'est pas verte.

# Exercice 5
Faire une page HTML contenant un bouton Afficher et un bouton Cacher. Au clic sur l'un ou sur l'autre afficher ou non un paragraphe de votre choix.

# Exercice 6
Faire une page HTML contenant deux paragrahes et deux boutons. Au clic sur le premier uniquement le paragrahe 1 doit être visible. Au clic sur le bouton deux, seulement le paragrahe 2 doit aparaître. 
