/*on déclare le module "schoolApp" auquel on passe un tableau vide
on va le lier à notre fichier html
*/
var schoolApp = angular.module('schoolApp',[]);
/*on ajoute un controller à notre appli qu'on nomme
studentsCtrl, notez la fonction du controller qui récupère le service $scope
*/
schoolApp.controller('studentsCtrl',function($scope){

  //on fournit au scope les variables firstName,lastName, age, grade
  $scope.firstName = 'Émilie';
  $scope.lastName = 'Gérard';
  $scope.age = 17;
  $scope.grade = 'Terminale';
});
