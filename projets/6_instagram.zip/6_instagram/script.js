$('.image1').hover(function(){
 $('.icon1').show();
}, function(){
 $('.icon1').hide();
});
$('.image2').hover(function(){
 $('.icon2').show();
}, function(){
 $('.icon2').hide();
});
$('.image3').hover(function(){
 $('.icon3').show();
}, function(){
 $('.icon3').hide();
});
$('.image4').hover(function(){
 $('.icon4').show();
}, function(){
 $('.icon4').hide();
});
$('.image5').hover(function(){
 $('.icon5').show();
}, function(){
 $('.icon5').hide();
});
$('.image6').hover(function(){
 $('.icon6').show();
}, function(){
 $('.icon6').hide();
});
